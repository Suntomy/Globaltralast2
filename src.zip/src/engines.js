/* ============================================================
   GLOBAL PILGRIM — ENGINES
   Live feed, 5-second direction robot, mining accrual,
   settlement processor, surveillance radar and clock.
   ============================================================ */
'use strict';

let ENGINES = [];
let radarZoom = 4.2;
let radarRAF = null;

const CITIES = [
  { n: 'Lagos', lat: 6.52, lon: 3.37 }, { n: 'Abuja', lat: 9.06, lon: 7.49 },
  { n: 'London', lat: 51.5, lon: -0.12 }, { n: 'Dubai', lat: 25.2, lon: 55.27 },
  { n: 'New York', lat: 40.71, lon: -74.0 }, { n: 'Singapore', lat: 1.35, lon: 103.82 },
  { n: 'Hong Kong', lat: 22.32, lon: 114.17 }, { n: 'Tokyo', lat: 35.68, lon: 139.69 },
  { n: 'Frankfurt', lat: 50.11, lon: 8.68 }, { n: 'Johannesburg', lat: -26.2, lon: 28.05 },
  { n: 'Sao Paulo', lat: -23.55, lon: -46.63 }, { n: 'Sydney', lat: -33.87, lon: 151.21 }
];

/* ---------------- lifecycle ---------------- */
function startEngines() {
  stopEngines();
  initMarkets();
  updateClock(); updateTicker();
  ENGINES.push(setInterval(updateClock, 1000));
  ENGINES.push(setInterval(updateTicker, 4000));
  ENGINES.push(setInterval(tickPrices, 1000));
  ENGINES.push(setInterval(robotCycle, 5000));
  ENGINES.push(setInterval(miningTick, 1000));
  ENGINES.push(setInterval(surveillanceTick, 12000));
  ENGINES.push(setInterval(refreshTradingOnly, 2000));
  drawRadar();
  const p = document.getElementById('enginePill');
  if (p) p.innerHTML = '<i class="dot"></i> Engine Live';
  logLine('ovLog', 'Execution engines armed at ' + (session ? session.node : 'HQ') + '.', 'ok');
  logLine('tradeLog', 'Robot standby. Feed streaming ' + MARKETS.length + ' instruments.', 'ok');
  logLine('mineLog', 'Mining core initialised. ' + S.mining.coins.filter(c => c.on).length + ' pools ready.', 'ok');
  logLine('survLog', 'Surveillance armed. Camera mesh ' + S.cameras.length + ' nodes.', 'ok');
}

function stopEngines() {
  ENGINES.forEach(clearInterval);
  ENGINES = [];
  if (radarRAF) { cancelAnimationFrame(radarRAF); radarRAF = null; }
}

/* ---------------- clock & ticker ---------------- */
function updateClock() {
  const d = new Date();
  const t = document.getElementById('clockTime');
  const dd = document.getElementById('clockDate');
  if (t) t.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  if (dd) dd.textContent = d.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }) + ' · UTC' + (d.getTimezoneOffset() > 0 ? '-' : '+') + Math.abs(d.getTimezoneOffset() / 60);
  const su = document.getElementById('statUptime');
  if (su) su.textContent = '99.99%';
}

function updateTicker() {
  const el = document.getElementById('ticker');
  if (!el) return;
  el.innerHTML = MARKETS.map(m => {
    const up = m.chg24 >= 0;
    return `<span class="tick">${esc(m.sym)} <b>${fmtPx(m)}</b> <em class="${up ? 'up' : 'down'}">${up ? '+' : ''}${m.chg24.toFixed(2)}%</em></span>`;
  }).join('');
}

/* ---------------- market feed ---------------- */
function initMarkets() {
  MARKETS.forEach(m => {
    if (m.last == null) m.last = m.price;
    if (!m.hist) m.hist = [];
  });
}

function tickPrices() {
  MARKETS.forEach(m => {
    const vol = m.cls === 'Forex' ? 0.0004 : m.cls === 'Metals' ? 0.0012 : m.cls === 'Minerals' ? 0.0015 : m.cls === 'Equity' ? 0.0018 : 0.0035;
    const drift = (Math.random() - 0.5) * vol;
    m.last = m.price;
    m.price = Math.max(0.0001, m.price * (1 + drift));
    m.chg24 = r2(m.chg24 + drift * 100 * 0.4);
    m.hist.push({ t: Date.now(), p: m.price });
    if (m.hist.length > 40) m.hist.shift();
  });
  S.positions.filter(p => p.open).forEach(p => {
    const m = MARKETS.find(x => x.sym === p.sym);
    if (m) p.now = m.price;
  });
  const fh = document.getElementById('feedHint');
  if (fh) fh.textContent = 'live · ' + shortTime(new Date());
}

function refreshTradingOnly() {
  if (document.getElementById('view-trading').classList.contains('on')) renderTrading();
  if (document.getElementById('view-overview').classList.contains('on')) {
    set('mTrading', money(S.wallets.trading) + ' <small>USD</small>', true);
    set('mProfit', money(S.wallets.profit) + ' <small>USD</small>', true);
    set('mEquity', money(totalEquity()) + ' <small>USD</small>', true);
  }
}

function refreshPrices() {
  tickPrices();
  renderTrading(); renderOverview(); updateTicker();
  toast('Feed synchronised across ' + MARKETS.length + ' instruments.', 'ok');
}

/* ---------------- trading robot ---------------- */
function toggleRobot() {
  S.robot.on = !S.robot.on;
  audit('ROBOT', 'Autonomous execution ' + (S.robot.on ? 'ACTIVATED' : 'DEACTIVATED'));
  save(); renderTrading(); renderOverview();
  logLine('tradeLog', 'Robot ' + (S.robot.on ? 'ACTIVATED — following 5s direction on all markets.' : 'DEACTIVATED — manual control only.'), S.robot.on ? 'ok' : 'warn');
  toast('Trading robot ' + (S.robot.on ? 'activated' : 'deactivated') + '.', S.robot.on ? 'ok' : '');
}

function robotCycle() {
  if (!S.robot.on || !session) return;
  const lot = Math.max(1, Number(S.settings.lot) || 250);
  const tp = Math.max(0.05, Number(S.settings.tp) || 1.2);
  MARKETS.forEach(m => {
    const h = m.hist.filter(x => x.t >= Date.now() - 5200);
    if (h.length < 3) return;
    const first = h[0].p, last = h[h.length - 1].p;
    const move = ((last - first) / first) * 100;
    if (Math.abs(move) < 0.004) return;
    const side = move > 0 ? 'BUY' : 'SELL';
    const open = S.positions.find(p => p.open && p.sym === m.sym && p.auto);
    if (open && open.side !== side) {
      closePosition(open.id, 'Direction reversal');
      return;
    }
    if (open) {
      const pnlPct = (positionPnl(open) / open.lot) * 100;
      if (pnlPct >= tp) closePosition(open.id, 'Take profit');
      return;
    }
    if (S.wallets.trading < lot) return;
    S.positions.push({
      id: uid('POS'), sym: m.sym, side, lot, entry: m.price, now: m.price,
      open: true, auto: true, ts: nowISO()
    });
    audit('ROBOT_OPEN', side + ' ' + m.sym + ' · ' + usd(lot) + ' · 5s ' + move.toFixed(3) + '%');
    logLine('tradeLog', 'ROBOT ' + side + ' ' + m.sym + ' @ ' + fmtPx(m) + ' · ' + usd(lot) + ' · 5s ' + (move >= 0 ? '+' : '') + move.toFixed(3) + '%', move >= 0 ? 'ok' : 'warn');
  });
  save();
}

function quickTrade(sym) {
  const m = MARKETS.find(x => x.sym === sym);
  if (!m) return;
  openModal('Execute — ' + sym, [
    { label: 'Side', type: 'select', options: ['BUY', 'SELL'] },
    { label: 'Notional (USD)', type: 'number', step: '1', value: '100' }
  ], v => {
    const lot = r2(v[1]);
    if (!(lot > 0)) return toast('Enter a valid notional.', 'er');
    if (lot > S.wallets.trading) return toast('Trading capital is insufficient.', 'er');
    S.positions.push({ id: uid('POS'), sym, side: v[0], lot, entry: m.price, now: m.price, open: true, auto: false, ts: nowISO() });
    audit('MANUAL_OPEN', v[0] + ' ' + sym + ' · ' + usd(lot));
    save(); renderTrading();
    logLine('tradeLog', 'MANUAL ' + v[0] + ' ' + sym + ' @ ' + fmtPx(m) + ' · ' + usd(lot), 'ok');
    toast('Order filled.', 'ok');
  });
}

function manualOrder() {
  const sym = document.getElementById('manSym').value;
  const side = document.getElementById('manSide').value;
  const amt = r2(document.getElementById('manAmt').value);
  const m = MARKETS.find(x => x.sym === sym);
  if (!m) return toast('Select an instrument.', 'er');
  if (!(amt > 0)) return toast('Enter a valid notional.', 'er');
  if (amt > S.wallets.trading) return toast('Trading capital is insufficient. Add capital first.', 'er');
  S.positions.push({ id: uid('POS'), sym, side, lot: amt, entry: m.price, now: m.price, open: true, auto: false, ts: nowISO() });
  audit('MANUAL_OPEN', side + ' ' + sym + ' · ' + usd(amt));
  save(); renderTrading();
  logLine('tradeLog', 'MANUAL ' + side + ' ' + sym + ' @ ' + fmtPx(m) + ' · ' + usd(amt), 'ok');
  toast(side + ' ' + sym + ' filled.', 'ok');
}

function closePosition(id, reason) {
  const p = S.positions.find(x => x.id === id);
  if (!p || !p.open) return;
  const pl = positionPnl(p);
  p.open = false; p.closedAt = nowISO(); p.realised = pl;
  if (pl > 0) {
    post({ type: 'TRADE_PNL', from: 'MARKET', to: 'profit', amount: pl, note: 'Realised profit · ' + p.sym + ' ' + p.side + (reason ? ' · ' + reason : '') });
  } else if (pl < 0) {
    const loss = Math.min(Math.abs(pl), S.wallets.trading);
    post({ type: 'TRADE_PNL', from: 'trading', to: 'MARKET', amount: loss, note: 'Realised loss · ' + p.sym + ' ' + p.side });
  }
  audit('POSITION_CLOSE', p.sym + ' ' + p.side + ' · P&L ' + usd(pl));
  save(); renderTrading(); renderOverview();
  logLine('tradeLog', 'CLOSE ' + p.sym + ' ' + p.side + ' · ' + (pl >= 0 ? '+' : '') + usd(pl) + (pl > 0 ? ' → Profit Balance' : ' → Trading Capital'), pl >= 0 ? 'ok' : 'warn');
  if (reason && !p.auto) toast('Position closed — ' + reason + '.', 'ok');
}

function takeProfitAll() {
  const open = S.positions.filter(p => p.open);
  if (!open.length) return toast('No open positions.', 'er');
  let total = 0;
  open.forEach(p => { total += positionPnl(p); closePosition(p.id, 'Manual take profit'); });
  toast('All positions closed. Net ' + (total >= 0 ? '+' : '') + usd(total) + '.', 'ok');
}

function adjustCapital(sign) {
  const addEl = document.getElementById('capAdd');
  const cutEl = document.getElementById('capCut');
  const amt = r2(sign > 0 ? addEl.value : cutEl.value);
  if (!(amt > 0)) return toast('Enter an amount first.', 'er');
  if (sign > 0) {
    if (S.wallets.main >= amt) {
      post({ type: 'CAPITAL_ADD', from: 'main', to: 'trading', amount: amt, note: 'Trading capital increase' });
    } else {
      post({ type: 'CAPITAL_ADD', from: 'EXTERNAL', to: 'trading', amount: amt, note: 'Owner capital injection' });
    }
    audit('CAPITAL_ADD', usd(amt) + ' to trading');
    logLine('tradeLog', 'CAPITAL +' + usd(amt) + ' → Trading Balance.', 'ok');
  } else {
    if (amt > S.wallets.trading) return toast('Reduce amount exceeds trading capital.', 'er');
    post({ type: 'CAPITAL_REDUCE', from: 'trading', to: 'main', amount: amt, note: 'Trading capital reduction' });
    audit('CAPITAL_REDUCE', usd(amt) + ' from trading');
    logLine('tradeLog', 'CAPITAL -' + usd(amt) + ' → Main Balance.', 'warn');
  }
  addEl.value = ''; cutEl.value = '';
  save(); renderTrading(); renderOverview(); renderWallets();
  toast('Trading capital updated.', 'ok');
}

function transferToMain(kind) {
  const bal = r2(S.wallets[kind] || 0);
  if (!(bal > 0)) return toast('Nothing to transfer from ' + (WALLET_LABELS[kind] || kind) + '.', 'er');
  const note = kind === 'profit'
    ? 'Profit realised from live Forex and capital-market trading — transferred to Main Balance'
    : 'Transfer from ' + (WALLET_LABELS[kind] || kind) + ' to Main Balance';
  post({ type: 'INTERNAL_TRANSFER', from: kind, to: 'main', amount: bal, note });
  audit('TRANSFER_MAIN', usd(bal) + ' from ' + kind);
  save(); renderAll();
  toast(usd(bal) + ' moved to Main Balance.', 'ok');
}

/* ---------------- mining ---------------- */
function startMining() {
  S.mining.on = true;
  audit('MINING_START', 'Continuous accrual activated');
  save(); renderMining(); renderOverview();
  logLine('mineLog', 'ENGINE START — accrual across ' + S.mining.coins.filter(c => c.on).length + ' pools. Runs until stopped.', 'ok');
  toast('Mining engine started. It will run until you stop it.', 'ok');
}

function stopMining() {
  S.mining.on = false;
  audit('MINING_STOP', 'Accrual halted by operator');
  save(); renderMining(); renderOverview();
  logLine('mineLog', 'ENGINE STOP — accrual halted by operator.', 'warn');
  toast('Mining engine stopped.', '');
}

function toggleCoin(i) {
  const c = S.mining.coins[i];
  if (!c) return;
  c.on = !c.on;
  audit('MINING_COIN', c.sym + ' ' + (c.on ? 'enabled' : 'paused'));
  save(); renderMining();
  logLine('mineLog', c.sym + ' pool ' + (c.on ? 'enabled' : 'paused') + '.', c.on ? 'ok' : 'warn');
}

function miningTick() {
  if (!S.mining.on) return;
  let add = 0;
  S.mining.coins.forEach(c => {
    if (!c.on) return;
    const inc = (c.rate / 60) * (0.85 + Math.random() * 0.3);
    c.accrued = +(c.accrued + inc).toFixed(4);
    add += inc;
  });
  S.mining.pending = +(S.mining.pending + add).toFixed(4);
  S.mining.hash = Math.round(380 + Math.random() * 90);
  if (S.settings.autoSettle && S.mining.pending >= 25) settleMining(true);
  if (Math.random() < 0.06) logLine('mineLog', 'Share accepted · +' + usd(add) + ' accrued · ' + Math.round(S.mining.hash) + ' MH/s', 'ok');
  save();
  if (document.getElementById('view-mining').classList.contains('on')) renderMining();
  set('wMining', usd(S.mining.pending));
}

function settleMining(silent) {
  const amt = +(S.mining.pending).toFixed(2);
  if (!(amt > 0)) { if (!silent) toast('No unsettled credits.', 'er'); return; }
  post({ type: 'MINING_SETTLE', from: 'MINING', to: 'main', amount: amt, note: 'Mining credits settled to Main Balance' });
  S.mining.settled = +(S.mining.settled + amt).toFixed(4);
  S.mining.pending = 0;
  S.mining.coins.forEach(c => c.accrued = 0);
  audit('MINING_SETTLE', usd(amt) + ' to Main Balance');
  save(); renderMining(); renderOverview(); renderWallets();
  logLine('mineLog', 'SETTLED ' + usd(amt) + ' → Main Balance.', 'ok');
  if (!silent) toast(usd(amt) + ' settled to Main Balance.', 'ok');
}

/* ---------------- internal transfer ---------------- */
function internalTransfer() {
  const from = document.getElementById('trFrom').value;
  const to = document.getElementById('trTo').value;
  const amt = r2(document.getElementById('trAmt').value);
  const note = document.getElementById('trNote').value.trim();
  if (from === to) return toast('Choose two different wallets.', 'er');
  if (!(amt > 0)) return toast('Enter a valid amount.', 'er');
  if (amt > S.wallets[from]) return toast('Insufficient balance in ' + WALLET_LABELS[from] + '.', 'er');
  post({ type: 'INTERNAL_TRANSFER', from, to, amount: amt, note: note || (WALLET_LABELS[from] + ' → ' + WALLET_LABELS[to]) });
  audit('TRANSFER', usd(amt) + ' ' + from + ' → ' + to);
  document.getElementById('trAmt').value = '';
  document.getElementById('trNote').value = '';
  save(); renderWallets(); renderOverview();
  toast('Transfer posted instantly. Zero fee.', 'ok');
}

/* ---------------- external settlement ---------------- */
function makeSettlement(o) {
  const feePct = Number(S.auth.fee) || 0.1;
  const fee = r2(o.amount * feePct / 100);
  const serial = 'GPB-' + new Date().getFullYear() + '-' + String(S.settlements.length + 1).padStart(5, '0');
  const txid = '0x' + hash(serial + o.amount + Date.now()).toLowerCase() + hash(String(Math.random())).toLowerCase().slice(0, 12);
  const tracking = 'TRK-' + hash(o.acctNo + serial).slice(0, 14);
  return {
    ts: nowISO(), serial, txid, tracking, feePct, fee,
    amount: r2(o.amount), net: r2(o.amount - fee),
    bank: o.bank, acctNo: o.acctNo, acctName: o.acctName, swift: o.swift || '',
    sort: o.sort || '', branch: o.branch || '', type: o.type || 'Business Account',
    method: o.method || 'SWIFT', note: o.note || '', status: o.status || 'PENDING',
    signature: hash(serial + txid + tracking).slice(0, 24),
    from: o.from || 'main'
  };
}

function submitSettlement() {
  const from = document.getElementById('bkFrom').value;
  const amt = r2(document.getElementById('bkAmt').value);
  const bank = document.getElementById('bkBank').value.trim();
  const acctNo = document.getElementById('bkAcct').value.trim();
  const acctName = document.getElementById('bkName').value.trim();
  const swift = document.getElementById('bkSwift').value.trim();
  const sort = document.getElementById('bkSort').value.trim();
  const branch = document.getElementById('bkBranch').value.trim();
  const type = document.getElementById('bkType').value;
  const method = document.getElementById('bkMethod').value;
  const note = document.getElementById('bkNote').value.trim();

  if (!(amt > 0)) return toast('Enter a valid settlement amount.', 'er');
  if (!bank) return toast('Beneficiary bank is required.', 'er');
  if (!/^\d{6,20}$/.test(acctNo)) return toast('Account number must be 6–20 digits.', 'er');
  if (!acctName) return toast('Account name is required.', 'er');
  const fee = r2(amt * (Number(S.auth.fee) || 0.1) / 100);
  if (amt + fee > S.wallets[from]) return toast('Insufficient balance including the ' + S.auth.fee + '% fee.', 'er');

  const s = makeSettlement({ from, amount: amt, bank, acctNo, acctName, swift, sort, branch, type, method, note, status: 'PROCESSING' });
  post({ type: 'EXTERNAL_SETTLEMENT', from, to: 'BANK', amount: r2(amt + fee), note: 'Settlement ' + s.serial + ' → ' + bank + ' · ' + acctNo });
  S.settlements.push(s);
  audit('SETTLEMENT', s.serial + ' · ' + usd(amt) + ' → ' + bank + ' · ' + acctNo);
  save(); renderBank(); renderWallets(); renderOverview();
  toast('Settlement authorised. Processing at Global Pilgrim Bank.', 'ok');

  setTimeout(() => {
    s.status = 'SUCCESSFUL';
    audit('SETTLEMENT_SUCCESS', s.serial + ' cleared');
    save(); renderBank(); renderOverview();
    toast('Settlement ' + s.serial + ' successful.', 'ok');
  }, 3200);
}

/* ---------------- surveillance ---------------- */
const TRANSPORTS = ['WiFi', 'Ethernet', 'Bluetooth', 'Wireless 5G', 'Fibre', 'Satellite'];
const DEVICES = ['Android 14', 'iOS 17', 'Windows 11', 'macOS 15', 'Linux x86_64', 'Unknown embedded'];
const SEVERITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

function pingSignals() {
  const n = 1 + Math.floor(Math.random() * 3);
  for (let i = 0; i < n; i++) {
    const city = pick(CITIES);
    const sig = {
      ts: nowISO(), transport: pick(TRANSPORTS), device: pick(DEVICES),
      origin: city.n + ', ' + (city.lat >= 0 ? 'N' : 'S') + Math.abs(city.lat).toFixed(2) + ' ' + (city.lon >= 0 ? 'E' : 'W') + Math.abs(city.lon).toFixed(2),
      ip: [Math.floor(Math.random() * 223) + 1, Math.floor(Math.random() * 255), Math.floor(Math.random() * 255), Math.floor(Math.random() * 254) + 1].join('.'),
      severity: pick(SEVERITIES), lat: city.lat + (Math.random() - 0.5) * 3, lon: city.lon + (Math.random() - 0.5) * 3
    };
    S.signals.push(sig);
    if (S.signals.length > 400) S.signals.splice(0, S.signals.length - 400);
    logLine('survLog', sig.transport + ' · ' + sig.origin + ' · ' + sig.device + ' · ' + sig.ip, sig.severity === 'CRITICAL' ? 'warn' : '');
    if (S.settings.autoAlarm && (sig.severity === 'HIGH' || sig.severity === 'CRITICAL')) {
      S.alarms.push({ ts: nowISO(), kind: 'Intrusion signal', severity: sig.severity, detail: sig.transport + ' from ' + sig.origin + ' · ' + sig.ip + ' · ' + sig.device, status: 'ACTIVE' });
    }
  }
  if (S.alarms.length > 300) S.alarms.splice(0, S.alarms.length - 300);
  audit('SIGNAL_SCAN', n + ' signals captured');
  save(); renderNetwork();
  toast(n + ' signal' + (n === 1 ? '' : 's') + ' captured.', 'ok');
}

function surveillanceTick() {
  if (!session) return;
  if (Math.random() < 0.55) pingSignals();
}

function raiseAlarm() {
  S.alarms.push({
    ts: nowISO(), kind: 'Manual test alarm', severity: 'HIGH',
    detail: 'Operator initiated alarm test at node ' + (session ? session.node : 'HQ') + ' · camera mesh requested', status: 'ACTIVE'
  });
  audit('ALARM_TEST', 'Manual alarm raised');
  save(); renderNetwork();
  logLine('survLog', 'ALARM raised — camera mesh requested.', 'warn');
  toast('Alarm raised and logged.', 'er');
}

function addCameraNode() {
  openModal('Attach Camera Node', [
    { label: 'Camera Label', placeholder: 'e.g. Lagos Perimeter 3' },
    { label: 'Location', placeholder: 'Street / City / Country' },
    { label: 'IP Address', placeholder: '10.0.0.24' },
    { label: 'Protocol', type: 'select', options: ['RTSP', 'ONVIF', 'HLS', 'WebRTC'] }
  ], v => {
    S.cameras.push({ label: v[0], location: v[1], ip: v[2], protocol: v[3], status: 'LIVE', ts: nowISO() });
    audit('CAMERA_ADD', v[0] + ' · ' + v[1] + ' · ' + v[2]);
    save(); renderNetwork();
    logLine('survLog', 'Camera attached: ' + v[0] + ' @ ' + v[1] + ' (' + v[3] + ')', 'ok');
    toast('Camera node attached.', 'ok');
  });
}

function zoomMap(f) {
  radarZoom = Math.min(24, Math.max(1, radarZoom * f));
  set('hudZoom', radarZoom.toFixed(1) + 'x');
  drawRadar();
}

/* ---------------- radar canvas ---------------- */
function drawRadar() {
  const cv = document.getElementById('radarCanvas');
  if (!cv) return;
  const wrap = cv.parentElement;
  const dpr = window.devicePixelRatio || 1;
  const w = wrap.clientWidth, h = wrap.clientHeight;
  if (!w || !h) return;
  cv.width = w * dpr; cv.height = h * dpr;
  cv.style.width = w + 'px'; cv.style.height = h + 'px';
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#050b14'); g.addColorStop(1, '#03070d');
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = 'rgba(47,208,187,.08)'; ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 34) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
  for (let y = 0; y < h; y += 34) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }

  ctx.fillStyle = 'rgba(47,208,187,.05)';
  const bands = [[0.12, 0.3, 0.22, 0.18], [0.4, 0.22, 0.16, 0.2], [0.58, 0.18, 0.28, 0.26], [0.2, 0.62, 0.16, 0.16], [0.62, 0.66, 0.2, 0.14]];
  bands.forEach(([bx, by, bw, bh]) => { ctx.beginPath(); ctx.ellipse(w * bx, h * by, w * bw, h * bh, 0, 0, Math.PI * 2); ctx.fill(); });

  const proj = (lat, lon) => [((lon + 180) / 360) * w, ((90 - lat) / 180) * h];

  const t = Date.now() / 1000;
  const cx = w / 2, cy = h / 2;
  const sweep = (t % 4) / 4 * Math.PI * 2;
  const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.62);
  rg.addColorStop(0, 'rgba(47,208,187,.18)'); rg.addColorStop(1, 'rgba(47,208,187,0)');
  ctx.fillStyle = rg;
  ctx.beginPath(); ctx.moveTo(cx, cy);
  ctx.arc(cx, cy, Math.max(w, h) * 0.62, sweep - 0.5, sweep); ctx.closePath(); ctx.fill();

  S.nodes.forEach((n, i) => {
    const a = (i / Math.max(1, S.nodes.length)) * Math.PI * 2 + t * 0.12;
    const r = Math.min(w, h) * (0.2 + (i % 3) * 0.1);
    const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r * 0.72;
    ctx.strokeStyle = 'rgba(201,162,39,.25)';
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x, y); ctx.stroke();
    ctx.fillStyle = '#c9a227';
    ctx.beginPath(); ctx.arc(x, y, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(232,198,90,.75)'; ctx.font = '9px ui-monospace,monospace';
    ctx.fillText(n.id, x + 5, y + 3);
  });

  CITIES.forEach(c => {
    const [x, y] = proj(c.lat, c.lon);
    ctx.fillStyle = 'rgba(75,141,255,.55)';
    ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
    if (radarZoom > 3) {
      ctx.fillStyle = 'rgba(147,160,183,.55)'; ctx.font = '8px ui-monospace,monospace';
      ctx.fillText(c.n, x + 4, y - 3);
    }
  });

  S.signals.slice(-40).forEach(s => {
    if (s.lat == null) return;
    const [x, y] = proj(s.lat, s.lon);
    const crit = s.severity === 'CRITICAL' || s.severity === 'HIGH';
    ctx.fillStyle = crit ? 'rgba(255,90,110,.9)' : 'rgba(47,208,187,.8)';
    ctx.beginPath(); ctx.arc(x, y, crit ? 3 : 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = crit ? 'rgba(255,90,110,.35)' : 'rgba(47,208,187,.28)';
    ctx.beginPath(); ctx.arc(x, y, 8 + (Math.sin(t * 3 + x) + 1) * 4, 0, Math.PI * 2); ctx.stroke();
  });

  S.cameras.forEach((c, i) => {
    const city = CITIES[i % CITIES.length];
    const [x, y] = proj(city.lat, city.lon);
    ctx.strokeStyle = 'rgba(201,162,39,.8)'; ctx.lineWidth = 1.4;
    ctx.strokeRect(x - 4, y - 4, 8, 8);
    ctx.beginPath(); ctx.moveTo(x, y - 8); ctx.lineTo(x, y - 14); ctx.stroke();
  });

  ctx.strokeStyle = 'rgba(232,198,90,.35)';
  ctx.beginPath(); ctx.moveTo(cx - 8, cy); ctx.lineTo(cx + 8, cy); ctx.moveTo(cx, cy - 8); ctx.lineTo(cx, cy + 8); ctx.stroke();

  const hc = document.getElementById('hudCoord');
  if (hc) {
    const lat = (Math.sin(t * 0.2) * 40).toFixed(4);
    const lon = (Math.cos(t * 0.17) * 90).toFixed(4);
    hc.innerHTML = 'LAT ' + lat + '<br>LON ' + lon;
  }
  set('hudZoom', radarZoom.toFixed(1) + 'x');
  set('hudNode', 'NODE: ' + (session ? session.node : 'HQ') + '-CORE');
  set('hudSignals', S.signals.length);
  set('hudAlarms', S.alarms.filter(a => a.status === 'ACTIVE').length);

  radarRAF = requestAnimationFrame(() => {
    if (session && document.getElementById('view-network').classList.contains('on')) drawRadar();
    else radarRAF = null;
  });
}

/* ---------------- boot ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  load();
  initMarkets();
  const y = document.getElementById('yr'); if (y) y.textContent = new Date().getFullYear();
  const sm = document.getElementById('statMarkets'); if (sm) sm.textContent = MARKETS.length;
  updateClock(); updateTicker();
  setInterval(updateClock, 1000);
  const saved = (() => { try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); } catch (e) { return null; } })();
  if (saved && saved.exp > Date.now()) {
    session = saved;
    document.getElementById('cover').style.display = 'none';
    document.getElementById('app').classList.add('on');
    document.getElementById('sideWho').textContent = saved.label || saved.id;
    document.getElementById('sideRole').textContent = saved.role === 'admin' ? 'Full Custody Access' : 'Client Access';
    document.getElementById('sSession').textContent = saved.node;
    renderAll(); startEngines(); resetSessionTimer();
  } else {
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
  }
  window.addEventListener('resize', () => { if (session) drawRadar(); });
  window.addEventListener('click', () => { if (session) resetSessionTimer(); });
  window.addEventListener('keydown', () => { if (session) resetSessionTimer(); });
});
